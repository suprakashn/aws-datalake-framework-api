from .pg_connect import Connector
from .rs_connect import RedshiftConnector

# IMPORT the module using from connector import Connector
